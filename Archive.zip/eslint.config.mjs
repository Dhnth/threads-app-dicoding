// For more info, see https://github.com/storybookjs/eslint-plugin-storybook#configuration-flat-config-format
import storybook from "eslint-plugin-storybook";

import js from "@eslint/js";
import globals from "globals";
import pluginReact from "eslint-plugin-react";
import { defineConfig } from "eslint/config";
import daStyle from "eslint-config-dicodingacademy";

export default defineConfig([
  {
    files: ["**/*.{js,mjs,cjs,jsx}"],
    plugins: { js },
    extends: ["js/recommended"],
    languageOptions: { 
      // Pembungkus globals yang benar:
      globals: {
        ...globals.browser,
        ...globals.jest
      }
    },
  },
  pluginReact.configs.flat.recommended,
  daStyle,
  ...storybook.configs["flat/recommended"],
]);